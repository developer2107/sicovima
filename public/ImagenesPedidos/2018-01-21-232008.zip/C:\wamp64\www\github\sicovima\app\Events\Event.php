<?php

namespace SICOVIMA\Events;

abstract class Event
{
    //
}
