<?php

namespace SICOVIMA;

use Illuminate\Database\Eloquent\Model;

class fecha extends Model
{
    protected $table = 'fecha';

    protected $fillable = ['fechai','fechaf'];

}

